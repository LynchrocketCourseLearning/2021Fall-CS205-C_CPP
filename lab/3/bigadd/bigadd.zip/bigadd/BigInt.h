#pragma once


int add( int* arr1, int len1, int* arr2, int len2, int* arr3, int len3 );

int multiple( int* arr1, int len1, int* arr2, int len2, int* arr3, int len3 );

int readInt( char* number, int* arr, int len );

void printInt( int* arr, int len );